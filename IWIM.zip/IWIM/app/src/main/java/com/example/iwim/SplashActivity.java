package com.example.iwim;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import java.util.concurrent.TimeUnit;

public  class SplashActivity extends AppCompatActivity {
    private Button buttonSub;
    private Button buttonLog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_splash);

        buttonSub = (Button) findViewById(R.id.button7);
        buttonLog = (Button) findViewById(R.id.button8);

        buttonSub.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             openActivitySub();
                                         }
                                     }
        );

        buttonLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityuser();

            }
        });
    }
                public void openActivityuser(){
                    Intent intent = new Intent(this,userActivity.class);
                    startActivity(intent);

        }
        public void openActivitySub(){

        Intent intent1 = new Intent(this,Subscribe.class);
        startActivity(intent1);

        }

    }


