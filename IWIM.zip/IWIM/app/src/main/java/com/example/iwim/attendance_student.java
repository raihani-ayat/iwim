package com.example.iwim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class attendance_student extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_student);
    }
}
