package com.example.iwim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class modifiy_teacher extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifiy_teacher);
    }
}
